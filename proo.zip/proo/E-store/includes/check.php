<?php
if(!isset($_SESSION)){
	header('location: login.php');
}
?>